package reto.bancolombia.model;

public class CargarDatos {

	private String origen;
	private String destino;
	private String fechaSalida;
	private String fechaRegreso;
	private String numeroViajeros;
	private String orientacion;
	private String resultadoEsperado;

	public String getOrigen() {
		return origen;
	}

	public String getDestino() {
		return destino;
	}

	public String getFechaSalida() {
		return fechaSalida;
	}

	public String getFechaRegreso() {
		return fechaRegreso;
	}

	public String getNumeroViajeros() {
		return numeroViajeros;
	}

	public String getOrientacion() {
		return orientacion;
	}

	public String getResultadoEsperado() {
		return resultadoEsperado;
	}

}
