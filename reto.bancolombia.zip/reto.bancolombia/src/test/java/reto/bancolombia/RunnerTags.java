package reto.bancolombia;

import org.junit.runner.RunWith;
import cucumber.api.CucumberOptions;

import net.serenitybdd.cucumber.CucumberWithSerenity;

@RunWith(CucumberWithSerenity.class)
@CucumberOptions(features = "src/test/resources/features/TiquetesAereos.feature", tags = "@TestCase4")
public class RunnerTags {
}
