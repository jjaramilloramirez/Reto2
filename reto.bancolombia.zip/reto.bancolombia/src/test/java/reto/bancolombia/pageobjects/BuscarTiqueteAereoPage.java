package reto.bancolombia.pageobjects;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;

import net.serenitybdd.core.pages.PageObject;
import net.thucydides.core.annotations.DefaultUrl;

@DefaultUrl("https://www.despegar.com.co/vuelos/")

public class BuscarTiqueteAereoPage extends PageObject {

	WebElement btnPopup;
	WebElement txtOrigen;
	WebElement txtDestino;
	WebElement txtPartida;
	WebElement txtRegreso;
	WebElement btnMesSiguiente;
	WebElement btnMesAnterior;
	WebElement txtPasajeros;
	WebElement btnAgregarAdulto;
	WebElement tbnBuscar;
	WebElement lblMensaje;

	public void ingresoDatosVuelo(String origen, String destino, String fechaSalida, String fechaRegreso,
			String numeroViajeros) {
		try {
			// Popup aprovecha los beneficios
			btnPopup = getDriver().findElement(By.xpath("//span[@class='as-login-close as-login-icon-close-circled']"));
			btnPopup.click();

			// Origen
			txtOrigen = getDriver().findElement(By.xpath("//input[@placeholder='Ingresa desde dónde viajas']"));
			txtOrigen.clear();
			txtOrigen.sendKeys(origen);
			Thread.sleep(1000);
			txtOrigen.sendKeys(Keys.ENTER);
			// Destino
			txtDestino = getDriver().findElement(By.xpath("//input[@placeholder='Ingresa hacia dónde viajas']"));
			txtDestino.clear();
			txtDestino.sendKeys(destino);
			Thread.sleep(1000);
			txtDestino.sendKeys(Keys.ENTER);
			List<WebElement> listTodosMeses = getDriver().findElements(By.xpath("//div[@class='_dpmg2--months']/div"));
			// Inicio Fecha partida
			if (fechaSalida.trim().length() >= 10) {
				txtPartida = getDriver().findElement(By.xpath("//input[@placeholder='Partida']"));
				txtPartida.click();
				Thread.sleep(1000);

				salirPartida: for (WebElement elementMes : listTodosMeses) {
					int intDia = Integer.parseInt(fechaSalida.substring(0, 2).trim());
					String strMes = fechaSalida.substring(3, 5).trim();
					String strAnio = fechaSalida.substring(6, 10).trim();
					if (!elementMes.getAttribute("data-month").equals(strAnio + "-" + strMes)) {
						btnMesSiguiente = getDriver().findElement(By.xpath("//div[@class='_dpmg2--controls-next']"));
						btnMesSiguiente.click();
					} else {
						// System.out.println(elementMes.getAttribute("data-month"));
						List<WebElement> listaTodosDias = getDriver().findElements(
								By.xpath("//div[@data-month='" + strAnio + "-" + strMes + "']/div[4]/span"));
						for (WebElement elementDia : listaTodosDias) {
							if (Integer.parseInt(elementDia.getText()) == (intDia)) {
								elementDia.click();
								break salirPartida;
							}
						}
					}
				}
			}
			// Fin Fecha partida

			// Inicio Fecha regreso
			if (fechaRegreso.trim().length() >= 10) {
				if (fechaSalida.trim().length() == 0) {
					txtRegreso = getDriver().findElement(By.xpath("//input[@placeholder='Regreso']"));
					txtRegreso.click();
					Thread.sleep(1000);
				}
				// List<WebElement> listTodosMeses = getDriver()
				// .findElements(By.xpath("//div[@class='_dpmg2--months']/div"));
				salirRegreso: for (WebElement elementMes : listTodosMeses) {
					int intDia = Integer.parseInt(fechaRegreso.substring(0, 2).trim());
					String strMes = fechaRegreso.substring(3, 5).trim();
					String strAnio = fechaRegreso.substring(6, 10).trim();
					if (!elementMes.getAttribute("data-month").equals(strAnio + "-" + strMes)) {
						// System.out.println(elementMes.getAttribute("data-month"));
						if (fechaSalida.trim().length() == 0) {
							btnMesSiguiente = getDriver()
									.findElement(By.xpath("//div[@class='_dpmg2--controls-next']"));
							btnMesSiguiente.click();
						}
					} else {
						// System.out.println(elementMes.getAttribute("data-month"));
						List<WebElement> listaTodosDias = getDriver().findElements(
								By.xpath("//div[@data-month='" + strAnio + "-" + strMes + "']/div[4]/span"));
						for (WebElement elementDia : listaTodosDias) {
							if (Integer.parseInt(elementDia.getText()) == (intDia)) {
								elementDia.click();
								break salirRegreso;
							}
						}
					}
				}
			}
			// Fin Fecha regreso

			// Numero y clase
			txtPasajeros = getDriver().findElement(By.xpath("//div[@class='sbox-distri-container']/div[6]/div[2]"));
			txtPasajeros.click();
			Thread.sleep(1000);
			for (int i = 0; i < Integer.parseInt(numeroViajeros) - 1; i++) {
				getDriver().findElement(By.xpath(
						"//div[@class='distpicker distpicker-flights']/div/div/div[2]/div/div/div/div/div[2]/div/a[2]"))
						.click();
			}

			// Boton buscar
			tbnBuscar = getDriver().findElement(
					By.xpath("//*[@id='searchbox-sbox-all-boxes']/div/div/div/div[3]/div[2]/div[4]/div/a"));
			tbnBuscar.click();
			System.out.println("Termiando de diligenciar el formulario de vuelos");
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public boolean verificarMensaje(String mensajeEsperado, String orientacion) {
		boolean resultado = false;
		String mensajeOptenido = null;
		switch (orientacion) {
		case "Acierto":
			break;

		case "Error":
			List<WebElement> lblMensajes = getDriver()
					.findElements(By.xpath("//*[contains(@class, 'validation-msg')]"));
			for (WebElement mensajeValidacion : lblMensajes) {
				mensajeOptenido = mensajeValidacion.getText().toLowerCase();
				if (mensajeOptenido.contains(mensajeEsperado.toLowerCase())) {
					resultado = true;
					System.out.println(mensajeValidacion.getText());
					break;
				}
			}
			break;
		}

		return resultado;
	}

}
