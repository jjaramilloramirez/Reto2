package reto.bancolombia.pageobjects;

import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.hssf.util.HSSFColor;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import net.serenitybdd.core.pages.PageObject;

public class ResultadoTiqueteAereoPage extends PageObject {

	WebElement lblMensaje;
	private static ArrayList<Integer> listPrecios;

	private void ordenarPreciosTiquetesAereos() {
		listPrecios = new ArrayList<Integer>();
		List<WebElement> listaElement = getDriver().findElements(By.xpath(
				"//*[@class='fare-couchmark-tooltip fare-box-container product-NONE']/span/span/div[1]/item-fare/p/span/flights-price/span/flights-price-element/span/span/em/span[2]"));
		for (WebElement elemntPrecio : listaElement) {
			// System.out.println(elemntPrecio.getText().replace(".", ""));
			listPrecios.add(Integer.parseInt(elemntPrecio.getText().replace(".", "")));
		}
		// Se organiza de forma asendente los precios.
		Collections.sort(listPrecios);

		// for (int precioTiquete : listPrecios) {
		// System.out.println(precioTiquete);
		// }
	}

	public void cargarlistaPrecioTiquetesExcel() {

		ordenarPreciosTiquetesAereos();
		try {
			String excelFileName = "src/test/resources/resultExcel/PreciosTiquetesAereos.xls";
			String sheetName = "PreciosTiquetes";
			HSSFWorkbook hssfWorkbook = new HSSFWorkbook();
			HSSFSheet hssfSheet = hssfWorkbook.createSheet(sheetName);
			int i = 0;
			for (int precioTiquete : listPrecios) {
				HSSFRow hssfRow = hssfSheet.createRow(i);
				HSSFCell hssfCell = hssfRow.createCell(0);
				if (i == 0) {
					HSSFCellStyle cellStyle = hssfWorkbook.createCellStyle();
					HSSFFont hssfFont = hssfWorkbook.createFont();
					hssfFont.setColor(HSSFColor.GREEN.index);
					cellStyle.setFont(hssfFont);
					hssfCell.setCellStyle(cellStyle);
				}
				hssfCell.setCellValue(String.valueOf(precioTiquete));
				i++;
			}

			FileOutputStream fileOut = new FileOutputStream(excelFileName);
			hssfWorkbook.write(fileOut);
			fileOut.flush();
			fileOut.close();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public boolean verificarMensaje(String mensajeEsperado, String orientacion) {
		boolean resultado = false;
		String mensajeOptenido = null;
		switch (orientacion) {
		case "Acierto":
			lblMensaje = getDriver().findElement(By.xpath(
					"//*[@class='fare-couchmark-tooltip fare-box-container product-NONE']/span/span/div[1]/item-fare/p/em[1]"));
			mensajeOptenido = lblMensaje.getText().trim();
			if (mensajeOptenido.equals(mensajeEsperado)) {
				System.out.println(lblMensaje.getText());
				resultado = true;
			}
			break;

		case "Error":
			break;
		}

		return resultado;
	}
}
