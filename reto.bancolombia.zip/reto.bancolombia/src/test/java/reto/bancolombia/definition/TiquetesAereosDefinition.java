package reto.bancolombia.definition;

import java.util.List;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import net.serenitybdd.core.Serenity;
import net.thucydides.core.annotations.Steps;
import reto.bancolombia.model.CargarDatos;
import reto.bancolombia.steps.TiquetesAereosSteps;

public class TiquetesAereosDefinition {

	@Steps
	CargarDatos stepModelCargarDatos;
	@Steps
	TiquetesAereosSteps stepTiquetesAereos;

	@Given("^Que Cargo los Datos de Busqueda$")
	public void que_Cargo_los_Datos_de_Busqueda(List<CargarDatos> listData) throws Throwable {
		CargarDatos cargarDatos = (CargarDatos) listData.get(0);
		Serenity.setSessionVariable("datos").to(cargarDatos);
	}

	@When("^Ingreso la informacion de vuelo$")
	public void ingreso_la_informacion_de_vuelo() throws Throwable {
		stepTiquetesAereos.ingresoPortalDespegar();
		stepTiquetesAereos.ingresoInformacionVuelo();
	}

	@Then("^Verifico precios de los tiquetes aereos$")
	public void verifico_precios_de_los_tiquetes_aereos() throws Throwable {
		stepTiquetesAereos.resultadoConsultaPreciosVuelo();
	}
}
