package reto.bancolombia.steps;

import static org.junit.Assert.assertTrue;

import org.fluentlenium.core.annotation.Page;

import net.serenitybdd.core.Serenity;
import reto.bancolombia.model.CargarDatos;
import reto.bancolombia.pageobjects.BuscarTiqueteAereoPage;
import reto.bancolombia.pageobjects.ResultadoTiqueteAereoPage;

public class TiquetesAereosSteps {

	CargarDatos data;

	@Page
	BuscarTiqueteAereoPage pageBuscarTiqueteAereo;
	ResultadoTiqueteAereoPage pageResultadoTiqueteAereo;

	public void ingresoPortalDespegar() {
		pageBuscarTiqueteAereo.open();
	}

	public void ingresoInformacionVuelo() {
		data = Serenity.sessionVariableCalled("datos");
		pageBuscarTiqueteAereo.ingresoDatosVuelo(data.getOrigen(), data.getDestino(), data.getFechaSalida(),
				data.getFechaRegreso(), data.getNumeroViajeros());
	}

	public void resultadoConsultaPreciosVuelo() {
		data = Serenity.sessionVariableCalled("datos");
		switch (data.getOrientacion()) {
		case "Acierto":
			pageResultadoTiqueteAereo.cargarlistaPrecioTiquetesExcel();
			assertTrue("Resultado consulta precios:",
					pageResultadoTiqueteAereo.verificarMensaje(data.getResultadoEsperado(), data.getOrientacion()));

			System.out.println(
					"Archivo: PreciosTiquetesAereos.xls. Fue generado en la ruta: src/test/resources/resultExcel/");
			break;

		case "Error":
			assertTrue("Mensaje validacion: " + data.getResultadoEsperado(),
					pageBuscarTiqueteAereo.verificarMensaje(data.getResultadoEsperado(), data.getOrientacion()));
			break;
		}

	}
}
